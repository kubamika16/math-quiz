// while (equations2.length < 5) {
// //   newQuestion2 = randomFromArray([divided, plus, minus, times]);
// //   if (calculations.includes(newQuestion2.calculation)) {
// //     console.log("zawiera");
// //   } else {
// //     equations2.push(newQuestion2);
// //     calculations.push(newQuestion2.calculation);
// //   }
// // }
