let count = 2;

for (let i = count; i >= 0; i--) {
  console.log("count w pętli", count);
  count--;
}
